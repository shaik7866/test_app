let selectedColor = null;
let timeRemaining = 120;

function selectColor(color) {
    selectedColor = color;
    document.getElementById("selected-color").textContent = `Selected Color: ${color}`;
}

// Countdown Timer
function startTimer() {
    const timerElement = document.getElementById("timer");
    const interval = setInterval(() => {
        timeRemaining--;
        const minutes = Math.floor(timeRemaining / 60);
        const seconds = timeRemaining % 60;
        timerElement.textContent = `Time Remaining: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        if (timeRemaining <= 0) {
            clearInterval(interval);
            showResult();
        }
    }, 1000);
}

// Show Result After 2 Minutes
function showResult() {
    const colors = ["Red", "Blue", "Green", "Yellow"];
    const winningColor = colors[Math.floor(Math.random() * colors.length)];

    const resultElement = document.getElementById("result");
    resultElement.textContent = `Winning Color: ${winningColor}`;

    if (selectedColor === winningColor) {
        resultElement.style.color = "green";
        resultElement.textContent += " - You Win!";
    } else {
        resultElement.style.color = "red";
        resultElement.textContent += " - You Lose!";
    }
}

// Start the timer on page load
window.onload = startTimer;